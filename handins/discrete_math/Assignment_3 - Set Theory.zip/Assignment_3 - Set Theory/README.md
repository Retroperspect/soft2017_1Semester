Assignment #3 - Set Theory
==========================
see project for code.

![CI Setup](Picture.png)
